window.getScreenWidth = () => {
    return window.innerWidth;
}